APM PHP Agent General Release 

How to Access the Product Documentation

The CA Application Performance Management product documentation is now available on a wiki platform.  We expect this will not only allow easier access to specific information, but also improve our ability to respond with improvements and enhancements. 

You can access the documentation from support.ca.com, as usual. In place of a bookshelf displaying, the documentation wiki displays. 

In the wiki, you can access the PHP Agent documentation by selecting Implementing Agents, then PHP Agent Implementation guide. 




